# Employee Attendance System

Simple full stack attendance tracking app with employee and manager roles.

## Tech used

Backend:
- Node.js
- Express
- MongoDB with Mongoose
- JWT for login

Frontend:
- React (Vite)
- React Router
- Zustand for auth state
- Recharts for manager charts

## Folder structure

- backend
- frontend

## How to run

You need Node.js and MongoDB.

### Backend

```bash
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev
```

Update `.env` if needed:

- MONGO_URI
- JWT_SECRET
- PORT
- CLIENT_URL

### Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

By default:
- frontend: http://localhost:5173
- backend: http://localhost:5000

## Seed users

`npm run seed` creates:

Manager:
- email: manager@example.com
- password: password123

Employees:
- alice@example.com / password123 / EMP001
- bob@example.com / password123 / EMP002

Some old attendance rows are also inserted so dashboards show data.

## Main features (short)

Employee:
- Login / register
- Check in and check out for today
- Dashboard with today status and this month stats
- Calendar view of own monthly attendance
- Profile view

Manager:
- Dashboard with total employees, today present/absent/late
- Weekly trend chart and department wise chart
- Table of employees absent today
- All attendance table with filters
- Team calendar by day
- Reports page with date range and CSV export