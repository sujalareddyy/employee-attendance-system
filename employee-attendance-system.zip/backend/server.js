import express from "express"
import dotenv from "dotenv"
import cors from "cors"
import morgan from "morgan"
import connectDb from "./src/config/db.js"
import authRoutes from "./src/routes/auth.js"
import attendanceRoutes from "./src/routes/attendance.js"
import dashboardRoutes from "./src/routes/dashboard.js"

dotenv.config()
const app = express()
const port = process.env.PORT || 5000
const clientUrl = process.env.CLIENT_URL || "http://localhost:5173"

connectDb()

app.use(cors({ origin: clientUrl, credentials: true }))
app.use(express.json())
app.use(morgan("dev"))

app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Employee Attendance API" })
})

app.use("/api/auth", authRoutes)
app.use("/api/attendance", attendanceRoutes)
app.use("/api/dashboard", dashboardRoutes)

app.use((req, res) => {
  res.status(404).json({ message: "Not found" })
})

app.use((err, req, res, next) => {
  const status = err.statusCode || 500
  res.status(status).json({ message: err.message || "Server error" })
})

app.listen(port, () => {
  console.log(`Server running on port ${port}`)
})