import dotenv from "dotenv"
import bcrypt from "bcryptjs"
import connectDb from "./src/config/db.js"
import User from "./src/models/User.js"
import Attendance from "./src/models/Attendance.js"

dotenv.config()

const run = async () => {
  await connectDb()
  await User.deleteMany({})
  await Attendance.deleteMany({})
  const passwordHash = await bcrypt.hash("password123", 10)
  const manager = await User.create({
    name: "Manager One",
    email: "manager@example.com",
    password: passwordHash,
    role: "manager",
    employeeId: "MGR001",
    department: "Management"
  })
  const emp1 = await User.create({
    name: "Alice Employee",
    email: "alice@example.com",
    password: passwordHash,
    role: "employee",
    employeeId: "EMP001",
    department: "Engineering"
  })
  const emp2 = await User.create({
    name: "Bob Employee",
    email: "bob@example.com",
    password: passwordHash,
    role: "employee",
    employeeId: "EMP002",
    department: "Sales"
  })
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const yesterday = new Date(today)
  yesterday.setDate(today.getDate() - 1)
  const dayBefore = new Date(today)
  dayBefore.setDate(today.getDate() - 2)
  const records = [
    {
      userId: emp1._id,
      date: dayBefore,
      checkInTime: new Date(dayBefore.getTime() + 9 * 60 * 60 * 1000),
      checkOutTime: new Date(dayBefore.getTime() + 17 * 60 * 60 * 1000),
      status: "present",
      totalHours: 8
    },
    {
      userId: emp1._id,
      date: yesterday,
      checkInTime: new Date(yesterday.getTime() + 10 * 60 * 60 * 1000),
      checkOutTime: new Date(yesterday.getTime() + 17 * 60 * 60 * 1000),
      status: "late",
      totalHours: 7
    },
    {
      userId: emp2._id,
      date: yesterday,
      checkInTime: new Date(yesterday.getTime() + 9 * 60 * 60 * 1000),
      checkOutTime: new Date(yesterday.getTime() + 13 * 60 * 60 * 1000),
      status: "half-day",
      totalHours: 4
    }
  ]
  await Attendance.insertMany(records)
  console.log("Seed completed")
  process.exit(0)
}

run().catch(err => {
  console.error(err)
  process.exit(1)
})