import express from "express"
import Attendance from "../models/Attendance.js"
import User from "../models/User.js"
import { auth, requireManager } from "../middleware/auth.js"
import { stringify } from "csv-stringify/sync"

const router = express.Router()

const startOfDay = date => {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  return d
}

const endOfDay = date => {
  const d = new Date(date)
  d.setHours(23, 59, 59, 999)
  return d
}

const monthRange = date => {
  const d = new Date(date)
  const start = new Date(d.getFullYear(), d.getMonth(), 1)
  const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999)
  return { start, end }
}

router.post("/checkin", auth, async (req, res) => {
  try {
    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    let record = await Attendance.findOne({ userId: req.user._id, date: { $gte: todayStart, $lte: todayEnd } })
    if (record && record.checkInTime) {
      return res.status(400).json({ message: "Already checked in" })
    }
    const workStart = new Date(now)
    workStart.setHours(9, 15, 0, 0)
    const late = now > workStart
    if (!record) {
      record = new Attendance({
        userId: req.user._id,
        date: todayStart,
        checkInTime: now,
        status: late ? "late" : "present"
      })
    } else {
      record.checkInTime = now
      if (late && record.status !== "late") {
        record.status = "late"
      }
    }
    await record.save()
    res.json({ message: "Checked in", record })
  } catch (err) {
    res.status(500).json({ message: "Check in failed" })
  }
})

router.post("/checkout", auth, async (req, res) => {
  try {
    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const record = await Attendance.findOne({ userId: req.user._id, date: { $gte: todayStart, $lte: todayEnd } })
    if (!record || !record.checkInTime) {
      return res.status(400).json({ message: "No check in for today" })
    }
    if (record.checkOutTime) {
      return res.status(400).json({ message: "Already checked out" })
    }
    record.checkOutTime = now
    const ms = record.checkOutTime.getTime() - record.checkInTime.getTime()
    const hours = ms / (1000 * 60 * 60)
    record.totalHours = Math.round(hours * 100) / 100
    if (record.totalHours < 4) {
      record.status = "half-day"
    }
    await record.save()
    res.json({ message: "Checked out", record })
  } catch (err) {
    res.status(500).json({ message: "Check out failed" })
  }
})

router.get("/my-history", auth, async (req, res) => {
  try {
    const { month, year } = req.query
    const base = new Date()
    if (month) {
      base.setMonth(parseInt(month) - 1)
    }
    if (year) {
      base.setFullYear(parseInt(year))
    }
    const { start, end } = monthRange(base)
    const records = await Attendance.find({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    }).sort({ date: -1 })
    res.json({ records })
  } catch (err) {
    res.status(500).json({ message: "Failed to load history" })
  }
})

router.get("/my-summary", auth, async (req, res) => {
  try {
    const base = new Date()
    const { start, end } = monthRange(base)
    const records = await Attendance.find({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    })
    let present = 0
    let late = 0
    let absent = 0
    let half = 0
    let totalHours = 0
    records.forEach(r => {
      if (r.status === "late") late += 1
      if (r.status === "present") present += 1
      if (r.status === "absent") absent += 1
      if (r.status === "half-day") half += 1
      totalHours += r.totalHours || 0
    })
    res.json({
      month: base.getMonth() + 1,
      year: base.getFullYear(),
      present,
      late,
      absent,
      halfDay: half,
      totalHours
    })
  } catch (err) {
    res.status(500).json({ message: "Failed to load summary" })
  }
})

router.get("/today", auth, async (req, res) => {
  try {
    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const record = await Attendance.findOne({ userId: req.user._id, date: { $gte: todayStart, $lte: todayEnd } })
    res.json({ record })
  } catch (err) {
    res.status(500).json({ message: "Failed to load today status" })
  }
})

router.get("/all", auth, requireManager, async (req, res) => {
  try {
    const { employeeId, date, status, from, to } = req.query
    const query = {}
    if (employeeId) {
      const user = await User.findOne({ employeeId })
      if (user) {
        query.userId = user._id
      } else {
        return res.json({ records: [] })
      }
    }
    if (date) {
      const d = new Date(date)
      query.date = { $gte: startOfDay(d), $lte: endOfDay(d) }
    }
    if (from && to) {
      const start = startOfDay(new Date(from))
      const end = endOfDay(new Date(to))
      query.date = { $gte: start, $lte: end }
    }
    if (status) {
      query.status = status
    }
    const records = await Attendance.find(query)
      .populate("userId", "name email employeeId department")
      .sort({ date: -1 })
    res.json({ records })
  } catch (err) {
    res.status(500).json({ message: "Failed to load attendance" })
  }
})

router.get("/employee/:id", auth, requireManager, async (req, res) => {
  try {
    const { id } = req.params
    const records = await Attendance.find({ userId: id }).sort({ date: -1 })
    res.json({ records })
  } catch (err) {
    res.status(500).json({ message: "Failed to load employee attendance" })
  }
})

router.get("/summary", auth, requireManager, async (req, res) => {
  try {
    const now = new Date()
    const { start, end } = monthRange(now)
    const agg = await Attendance.aggregate([
      { $match: { date: { $gte: start, $lte: end } } },
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 }
        }
      }
    ])
    const result = { present: 0, late: 0, absent: 0, halfDay: 0 }
    agg.forEach(a => {
      if (a._id === "present") result.present = a.count
      if (a._id === "late") result.late = a.count
      if (a._id === "absent") result.absent = a.count
      if (a._id === "half-day") result.halfDay = a.count
    })
    res.json(result)
  } catch (err) {
    res.status(500).json({ message: "Failed to load summary" })
  }
})

router.get("/export", auth, requireManager, async (req, res) => {
  try {
    const { from, to, employeeId } = req.query
    const query = {}
    if (from && to) {
      const start = startOfDay(new Date(from))
      const end = endOfDay(new Date(to))
      query.date = { $gte: start, $lte: end }
    }
    if (employeeId) {
      const user = await User.findOne({ employeeId })
      if (user) {
        query.userId = user._id
      } else {
        return res.json({ url: null })
      }
    }
    const records = await Attendance.find(query).populate("userId", "name employeeId department")
    const rows = records.map(r => ({
      employeeId: r.userId.employeeId,
      name: r.userId.name,
      department: r.userId.department,
      date: r.date.toISOString().slice(0, 10),
      checkInTime: r.checkInTime ? r.checkInTime.toISOString() : "",
      checkOutTime: r.checkOutTime ? r.checkOutTime.toISOString() : "",
      status: r.status,
      totalHours: r.totalHours
    }))
    const csv = stringify(rows, { header: true })
    res.header("Content-Type", "text/csv")
    res.attachment("attendance.csv")
    res.send(csv)
  } catch (err) {
    res.status(500).json({ message: "Failed to export csv" })
  }
})

router.get("/today-status", auth, requireManager, async (req, res) => {
  try {
    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const records = await Attendance.find({ date: { $gte: todayStart, $lte: todayEnd } }).populate(
      "userId",
      "name employeeId department"
    )
    res.json({ records })
  } catch (err) {
    res.status(500).json({ message: "Failed to load today status" })
  }
})

export default router