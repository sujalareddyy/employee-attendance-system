import express from "express"
import Attendance from "../models/Attendance.js"
import User from "../models/User.js"
import { auth, requireManager } from "../middleware/auth.js"

const router = express.Router()

const startOfDay = date => {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  return d
}

const endOfDay = date => {
  const d = new Date(date)
  d.setHours(23, 59, 59, 999)
  return d
}

const monthRange = date => {
  const d = new Date(date)
  const start = new Date(d.getFullYear(), d.getMonth(), 1)
  const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999)
  return { start, end }
}

router.get("/employee", auth, async (req, res) => {
  try {
    const now = new Date()
    const { start, end } = monthRange(now)
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const records = await Attendance.find({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    }).sort({ date: -1 })
    const today = await Attendance.findOne({
      userId: req.user._id,
      date: { $gte: todayStart, $lte: todayEnd }
    })
    let present = 0
    let late = 0
    let absent = 0
    let half = 0
    let totalHours = 0
    records.forEach(r => {
      if (r.status === "present") present += 1
      if (r.status === "late") late += 1
      if (r.status === "absent") absent += 1
      if (r.status === "half-day") half += 1
      totalHours += r.totalHours || 0
    })
    const recent = records.slice(0, 7)
    res.json({
      todayStatus: today || null,
      stats: {
        present,
        late,
        absent,
        halfDay: half,
        totalHours
      },
      recent
    })
  } catch (err) {
    res.status(500).json({ message: "Failed to load dashboard" })
  }
})

router.get("/manager", auth, requireManager, async (req, res) => {
  try {
    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const { start, end } = monthRange(now)
    const totalEmployees = await User.countDocuments({ role: "employee" })
    const todayRecords = await Attendance.find({
      date: { $gte: todayStart, $lte: todayEnd }
    }).populate("userId", "department")
    let present = 0
    let absent = 0
    let lateArrivals = 0
    todayRecords.forEach(r => {
      if (r.status === "present" || r.status === "late" || r.status === "half-day") {
        present += 1
      }
      if (r.status === "late") {
        lateArrivals += 1
      }
    })
    absent = totalEmployees - present
    const deptAgg = await Attendance.aggregate([
      { $match: { date: { $gte: start, $lte: end } } },
      {
        $lookup: {
          from: "users",
          localField: "userId",
          foreignField: "_id",
          as: "user"
        }
      },
      { $unwind: "$user" },
      {
        $group: {
          _id: "$user.department",
          presentCount: {
            $sum: {
              $cond: [{ $in: ["$status", ["present", "late", "half-day"]]}, 1, 0]
            }
          }
        }
      }
    ])
    const departmentWise = deptAgg.map(d => ({
      department: d._id,
      present: d.presentCount
    }))
    const weekAgo = new Date(now)
    weekAgo.setDate(now.getDate() - 6)
    const trendAgg = await Attendance.aggregate([
      {
        $match: {
          date: { $gte: startOfDay(weekAgo), $lte: endOfDay(now) }
        }
      },
      {
        $group: {
          _id: {
            y: { $year: "$date" },
            m: { $month: "$date" },
            d: { $dayOfMonth: "$date" }
          },
          presentCount: {
            $sum: {
              $cond: [{ $in: ["$status", ["present", "late", "half-day"]]}, 1, 0]
            }
          }
        }
      },
      {
        $sort: { "_id.y": 1, "_id.m": 1, "_id.d": 1 }
      }
    ])
    const weeklyTrend = trendAgg.map(t => ({
      date: `${t._id.y}-${String(t._id.m).padStart(2, "0")}-${String(t._id.d).padStart(2, "0")}`,
      present: t.presentCount
    }))
    const absentEmployeesAgg = await User.aggregate([
      { $match: { role: "employee" } },
      {
        $lookup: {
          from: "attendances",
          let: { userId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$userId", "$$userId"] },
                    { $gte: ["$date", todayStart] },
                    { $lte: ["$date", todayEnd] }
                  ]
                }
              }
            }
          ],
          as: "todayAttendance"
        }
      },
      {
        $match: { todayAttendance: { $size: 0 } }
      },
      {
        $project: {
          _id: 1,
          name: 1,
          employeeId: 1,
          department: 1
        }
      }
    ])
    res.json({
      totalEmployees,
      today: {
        present,
        absent,
        lateArrivals
      },
      weeklyTrend,
      departmentWise,
      absentEmployeesToday: absentEmployeesAgg
    })
  } catch (err) {
    res.status(500).json({ message: "Failed to load manager dashboard" })
  }
})

export default router