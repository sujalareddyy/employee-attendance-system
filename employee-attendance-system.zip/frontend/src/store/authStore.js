import { create } from "zustand"
import { api } from "../api"

const useAuthStore = create(set => ({
  user: null,
  token: localStorage.getItem("token") || "",
  loading: false,
  error: "",
  setUser: user => set({ user }),
  logout: () => {
    localStorage.removeItem("token")
    set({ user: null, token: "", error: "" })
  },
  login: async (email, password) => {
    set({ loading: true, error: "" })
    try {
      const res = await api.post("/auth/login", { email, password })
      localStorage.setItem("token", res.data.token)
      set({ user: res.data.user, token: res.data.token, loading: false })
      return true
    } catch (err) {
      set({ loading: false, error: err.response?.data?.message || "Login failed" })
      return false
    }
  },
  register: async payload => {
    set({ loading: true, error: "" })
    try {
      const res = await api.post("/auth/register", payload)
      localStorage.setItem("token", res.data.token)
      set({ user: res.data.user, token: res.data.token, loading: false })
      return true
    } catch (err) {
      set({ loading: false, error: err.response?.data?.message || "Registration failed" })
      return false
    }
  },
  fetchMe: async () => {
    set({ loading: true })
    try {
      const res = await api.get("/auth/me")
      set({ user: res.data.user, loading: false })
    } catch (err) {
      set({ user: null, token: "", loading: false })
      localStorage.removeItem("token")
    }
  }
}))

export default useAuthStore