import React, { useEffect } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import useAuthStore from "../store/authStore"

const ProtectedRoute = ({ children, role }) => {
  const { user, token, fetchMe } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    if (!token) {
      navigate("/login", { replace: true, state: { from: location.pathname } })
      return
    }
    if (!user) {
      fetchMe()
    }
  }, [token])

  useEffect(() => {
    if (user && role && user.role !== role) {
      if (user.role === "manager") {
        navigate("/manager/dashboard", { replace: true })
      } else {
        navigate("/dashboard", { replace: true })
      }
    }
  }, [user, role])

  if (!token) {
    return null
  }

  if (!user) {
    return <div style={{ padding: 20 }}>Loading...</div>
  }

  return children
}

export default ProtectedRoute