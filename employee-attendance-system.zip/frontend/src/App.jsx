import React from "react"
import { Routes, Route, Navigate, NavLink, useLocation } from "react-router-dom"
import useAuthStore from "./store/authStore"
import LoginPage from "./pages/LoginPage"
import RegisterPage from "./pages/RegisterPage"
import EmployeeDashboard from "./pages/EmployeeDashboard"
import MarkAttendance from "./pages/MarkAttendance"
import MyHistory from "./pages/MyHistory"
import ProfilePage from "./pages/ProfilePage"
import ManagerDashboard from "./pages/ManagerDashboard"
import AllAttendance from "./pages/AllAttendance"
import TeamCalendar from "./pages/TeamCalendar"
import ReportsPage from "./pages/ReportsPage"
import ProtectedRoute from "./components/ProtectedRoute"

const Layout = ({ children }) => {
  const { user, logout } = useAuthStore()
  const location = useLocation()
  const isManager = user && user.role === "manager"
  const linksEmployee = [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/attendance/mark", label: "Mark Attendance" },
    { to: "/attendance/history", label: "My Attendance" },
    { to: "/profile", label: "Profile" }
  ]
  const linksManager = [
    { to: "/manager/dashboard", label: "Dashboard" },
    { to: "/manager/attendance", label: "All Attendance" },
    { to: "/manager/calendar", label: "Team Calendar" },
    { to: "/manager/reports", label: "Reports" }
  ]
  const links = isManager ? linksManager : linksEmployee
  return (
    <div className="layout">
      <aside className="sidebar">
        <h2>Attendance</h2>
        {user && (
          <div style={{ marginBottom: 12, fontSize: 13 }}>
            <div>{user.name}</div>
            <div style={{ opacity: 0.8 }}>{user.role.toUpperCase()}</div>
          </div>
        )}
        <nav>
          {links.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => (isActive ? "active" : "")}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <button className="button secondary" style={{ marginTop: 16 }} onClick={logout}>
          Logout
        </button>
      </aside>
      <main className="main">
        {children}
      </main>
    </div>
  )
}

const App = () => {
  const { user } = useAuthStore()

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute role="employee">
            <Layout>
              <EmployeeDashboard />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/attendance/mark"
        element={
          <ProtectedRoute role="employee">
            <Layout>
              <MarkAttendance />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/attendance/history"
        element={
          <ProtectedRoute role="employee">
            <Layout>
              <MyHistory />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <Layout>
              <ProfilePage />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/manager/dashboard"
        element={
          <ProtectedRoute role="manager">
            <Layout>
              <ManagerDashboard />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/manager/attendance"
        element={
          <ProtectedRoute role="manager">
            <Layout>
              <AllAttendance />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/manager/calendar"
        element={
          <ProtectedRoute role="manager">
            <Layout>
              <TeamCalendar />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/manager/reports"
        element={
          <ProtectedRoute role="manager">
            <Layout>
              <ReportsPage />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/"
        element={
          user ? (
            user.role === "manager" ? (
              <Navigate to="/manager/dashboard" replace />
            ) : (
              <Navigate to="/dashboard" replace />
            )
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
    </Routes>
  )
}

export default App