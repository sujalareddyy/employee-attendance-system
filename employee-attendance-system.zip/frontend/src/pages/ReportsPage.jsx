import React, { useState } from "react"
import { api } from "../api"

const ReportsPage = () => {
  const [filters, setFilters] = useState({
    from: "",
    to: "",
    employeeId: ""
  })
  const [records, setRecords] = useState([])

  const handleChange = e => {
    setFilters({ ...filters, [e.target.name]: e.target.value })
  }

  const handleLoad = async () => {
    try {
      const res = await api.get("/attendance/all", {
        params: {
          employeeId: filters.employeeId,
          from: filters.from,
          to: filters.to
        }
      })
      setRecords(res.data.records)
    } catch (err) {
      console.error(err)
    }
  }

  const handleExport = () => {
    const params = new URLSearchParams(filters).toString()
    window.location.href = `${api.defaults.baseURL}/attendance/export?${params}`
  }

  return (
    <div>
      <div className="topbar">
        <h2>Reports</h2>
      </div>
      <div className="card">
        <div className="grid grid-3">
          <div className="form-group">
            <label>From</label>
            <input name="from" type="date" value={filters.from} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>To</label>
            <input name="to" type="date" value={filters.to} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Employee ID (optional)</label>
            <input name="employeeId" value={filters.employeeId} onChange={handleChange} />
          </div>
        </div>
        <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
          <button className="button" onClick={handleLoad}>
            Load
          </button>
          <button className="button secondary" onClick={handleExport}>
            Export CSV
          </button>
        </div>
      </div>
      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Employee</th>
              <th>Employee ID</th>
              <th>Status</th>
              <th>Total Hours</th>
            </tr>
          </thead>
          <tbody>
            {records.map(r => (
              <tr key={r._id}>
                <td>{new Date(r.date).toISOString().slice(0, 10)}</td>
                <td>{r.userId?.name}</td>
                <td>{r.userId?.employeeId}</td>
                <td>
                  <span className={"chip " + r.status.replace("half-day", "half-day")}>{r.status}</span>
                </td>
                <td>{r.totalHours?.toFixed(1) || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default ReportsPage