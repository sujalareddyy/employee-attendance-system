import React, { useEffect, useMemo, useState } from "react"
import { api } from "../api"

const TeamCalendar = () => {
  const [records, setRecords] = useState([])
  const [month, setMonth] = useState(new Date().getMonth() + 1)
  const [year, setYear] = useState(new Date().getFullYear())

  const load = async () => {
    try {
      const from = `${year}-${String(month).padStart(2, "0")}-01`
      const toDate = new Date(year, month, 0).getDate()
      const to = `${year}-${String(month).padStart(2, "0")}-${String(toDate).padStart(2, "0")}`
      const res = await api.get("/attendance/all", {
        params: { from, to }
      })
      setRecords(res.data.records)
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    load()
  }, [month, year])

  const byDate = useMemo(() => {
    const map = {}
    records.forEach(r => {
      const key = new Date(r.date).toISOString().slice(0, 10)
      if (!map[key]) map[key] = []
      map[key].push(r)
    })
    return map
  }, [records])

  const days = useMemo(() => {
    const first = new Date(year, month - 1, 1)
    const last = new Date(year, month, 0)
    const arr = []
    for (let d = 1; d <= last.getDate(); d++) {
      const dateObj = new Date(year, month - 1, d)
      const key = dateObj.toISOString().slice(0, 10)
      const items = byDate[key] || []
      arr.push({
        date: d,
        key,
        records: items
      })
    }
    return arr
  }, [month, year, byDate])

  return (
    <div>
      <div className="topbar">
        <h2>Team Calendar</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <select value={month} onChange={e => setMonth(parseInt(e.target.value))}>
            {Array.from({ length: 12 }).map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
          <select value={year} onChange={e => setYear(parseInt(e.target.value))}>
            {Array.from({ length: 3 }).map((_, i) => {
              const y = new Date().getFullYear() - 1 + i
              return (
                <option key={y} value={y}>
                  {y}
                </option>
              )
            })}
          </select>
        </div>
      </div>
      <div className="card">
        <div className="calendar-grid">
          {days.map(day => {
            const presentCount = day.records.filter(
              r => r.status === "present" || r.status === "late" || r.status === "half-day"
            ).length
            const absentCount = day.records.length - presentCount
            let cls = ""
            if (presentCount > 0 && absentCount === 0) cls = "present"
            else if (presentCount === 0 && day.records.length > 0) cls = "absent"
            else if (presentCount > 0 && absentCount > 0) cls = "late"
            return (
              <div key={day.key} className={"calendar-day " + cls}>
                <span className="date-label">{day.date}</span>
                <span>Present: {presentCount}</span>
                <span>Absent: {absentCount}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default TeamCalendar