import React, { useEffect, useMemo, useState } from "react"
import { api } from "../api"

const MyHistory = () => {
  const [records, setRecords] = useState([])
  const [month, setMonth] = useState(new Date().getMonth() + 1)
  const [year, setYear] = useState(new Date().getFullYear())

  const load = async () => {
    try {
      const res = await api.get("/attendance/my-history", {
        params: { month, year }
      })
      setRecords(res.data.records)
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    load()
  }, [month, year])

  const byDate = useMemo(() => {
    const map = {}
    records.forEach(r => {
      const key = new Date(r.date).toISOString().slice(0, 10)
      map[key] = r
    })
    return map
  }, [records])

  const days = useMemo(() => {
    const first = new Date(year, month - 1, 1)
    const last = new Date(year, month, 0)
    const arr = []
    for (let d = 1; d <= last.getDate(); d++) {
      const dateObj = new Date(year, month - 1, d)
      const key = dateObj.toISOString().slice(0, 10)
      const rec = byDate[key]
      arr.push({
        date: d,
        key,
        status: rec?.status || "absent",
        record: rec
      })
    }
    return arr
  }, [month, year, byDate])

  const handleMonthChange = e => {
    setMonth(parseInt(e.target.value))
  }

  const handleYearChange = e => {
    setYear(parseInt(e.target.value))
  }

  return (
    <div>
      <div className="topbar">
        <h2>My Attendance History</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <select value={month} onChange={handleMonthChange}>
            {Array.from({ length: 12 }).map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
          <select value={year} onChange={handleYearChange}>
            {Array.from({ length: 3 }).map((_, i) => {
              const y = new Date().getFullYear() - 1 + i
              return (
                <option key={y} value={y}>
                  {y}
                </option>
              )
            })}
          </select>
        </div>
      </div>
      <div className="card">
        <div className="calendar-grid">
          {days.map(day => (
            <div
              key={day.key}
              className={
                "calendar-day " +
                (day.status === "present"
                  ? "present"
                  : day.status === "late"
                  ? "late"
                  : day.status === "half-day"
                  ? "half-day"
                  : "absent")
              }
            >
              <span className="date-label">{day.date}</span>
              <span>{day.status}</span>
              {day.record && day.record.totalHours ? (
                <span>{day.record.totalHours.toFixed(1)} h</span>
              ) : null}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default MyHistory