import React, { useState } from "react"
import { Link, useNavigate, useLocation } from "react-router-dom"
import useAuthStore from "../store/authStore"

const LoginPage = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { login, loading, error } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()

  const handleSubmit = async e => {
    e.preventDefault()
    const ok = await login(email, password)
    if (ok) {
      const from = location.state?.from
      const user = useAuthStore.getState().user
      if (from) {
        navigate(from, { replace: true })
      } else if (user && user.role === "manager") {
        navigate("/manager/dashboard", { replace: true })
      } else {
        navigate("/dashboard", { replace: true })
      }
    }
  }

  return (
    <div style={{ maxWidth: 400, margin: "60px auto" }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email</label>
          <input value={email} onChange={e => setEmail(e.target.value)} type="email" />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" />
        </div>
        {error && <div style={{ color: "red", fontSize: 13, marginBottom: 8 }}>{error}</div>}
        <button className="button" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
      <p style={{ marginTop: 16, fontSize: 14 }}>
        Do not have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  )
}

export default LoginPage