import React, { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import useAuthStore from "../store/authStore"

const RegisterPage = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    employeeId: "",
    department: "",
    role: "employee"
  })
  const { register, loading, error } = useAuthStore()
  const navigate = useNavigate()

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async e => {
    e.preventDefault()
    const ok = await register(form)
    if (ok) {
      if (form.role === "manager") {
        navigate("/manager/dashboard", { replace: true })
      } else {
        navigate("/dashboard", { replace: true })
      }
    }
  }

  return (
    <div style={{ maxWidth: 440, margin: "40px auto" }}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name</label>
          <input name="name" value={form.name} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input name="email" type="email" value={form.email} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input name="password" type="password" value={form.password} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>Employee ID</label>
          <input name="employeeId" value={form.employeeId} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>Department</label>
          <input name="department" value={form.department} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label>Role</label>
          <select name="role" value={form.role} onChange={handleChange}>
            <option value="employee">Employee</option>
            <option value="manager">Manager</option>
          </select>
        </div>
        {error && <div style={{ color: "red", fontSize: 13, marginBottom: 8 }}>{error}</div>}
        <button className="button" disabled={loading}>
          {loading ? "Registering..." : "Register"}
        </button>
      </form>
      <p style={{ marginTop: 16, fontSize: 14 }}>
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  )
}

export default RegisterPage