import React, { useEffect, useState } from "react"
import { api } from "../api"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Legend, ResponsiveContainer } from "recharts"

const ManagerDashboard = () => {
  const [data, setData] = useState(null)

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get("/dashboard/manager")
        setData(res.data)
      } catch (err) {
        console.error(err)
      }
    }
    load()
  }, [])

  if (!data) {
    return <div>Loading...</div>
  }

  return (
    <div>
      <div className="topbar">
        <h2>Manager Dashboard</h2>
      </div>
      <div className="grid grid-3">
        <div className="card">
          <div>Total Employees</div>
          <div style={{ fontSize: 22, fontWeight: 600, marginTop: 8 }}>{data.totalEmployees}</div>
        </div>
        <div className="card">
          <div>Today</div>
          <div style={{ marginTop: 8, fontSize: 14 }}>
            <div>Present: {data.today.present}</div>
            <div>Absent: {data.today.absent}</div>
            <div>Late Arrivals: {data.today.lateArrivals}</div>
          </div>
        </div>
        <div className="card">
          <div>Absent Today</div>
          <div style={{ fontSize: 22, fontWeight: 600, marginTop: 8 }}>{data.absentEmployeesToday.length}</div>
        </div>
      </div>
      <div className="grid" style={{ marginTop: 16 }}>
        <div className="card">
          <h3>Weekly Attendance Trend</h3>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <LineChart data={data.weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="present" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card">
          <h3>Department Wise Attendance</h3>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={data.departmentWise}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="present" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <div className="card">
        <h3>Absent Employees Today</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Employee</th>
              <th>Employee ID</th>
              <th>Department</th>
            </tr>
          </thead>
          <tbody>
            {data.absentEmployeesToday.map(emp => (
              <tr key={emp._id}>
                <td>{emp.name}</td>
                <td>{emp.employeeId}</td>
                <td>{emp.department}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default ManagerDashboard