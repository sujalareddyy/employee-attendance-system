import React, { useEffect, useState } from "react"
import { api } from "../api"

const MarkAttendance = () => {
  const [today, setToday] = useState(null)
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [message, setMessage] = useState("")

  const loadToday = async () => {
    setLoading(true)
    try {
      const res = await api.get("/attendance/today")
      setToday(res.data.record)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadToday()
  }, [])

  const handleCheckIn = async () => {
    setSending(true)
    setMessage("")
    try {
      const res = await api.post("/attendance/checkin")
      setMessage(res.data.message)
      await loadToday()
    } catch (err) {
      setMessage(err.response?.data?.message || "Failed to check in")
    } finally {
      setSending(false)
    }
  }

  const handleCheckOut = async () => {
    setSending(true)
    setMessage("")
    try {
      const res = await api.post("/attendance/checkout")
      setMessage(res.data.message)
      await loadToday()
    } catch (err) {
      setMessage(err.response?.data?.message || "Failed to check out")
    } finally {
      setSending(false)
    }
  }

  if (loading) {
    return <div>Loading...</div>
  }

  const checkedIn = today && today.checkInTime
  const checkedOut = today && today.checkOutTime

  return (
    <div>
      <div className="topbar">
        <h2>Mark Attendance</h2>
      </div>
      <div className="card">
        <div style={{ marginBottom: 12 }}>
          Today: {new Date().toISOString().slice(0, 10)}
        </div>
        <div style={{ marginBottom: 12 }}>
          Status: {today ? today.status : "Not marked"}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="button" disabled={sending || checkedIn} onClick={handleCheckIn}>
            Check In
          </button>
          <button className="button secondary" disabled={sending || !checkedIn || checkedOut} onClick={handleCheckOut}>
            Check Out
          </button>
        </div>
        {message && <div style={{ marginTop: 12, fontSize: 13 }}>{message}</div>}
      </div>
    </div>
  )
}

export default MarkAttendance