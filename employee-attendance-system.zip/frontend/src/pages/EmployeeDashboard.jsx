import React, { useEffect, useState } from "react"
import { api } from "../api"

const EmployeeDashboard = () => {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get("/dashboard/employee")
        setData(res.data)
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  if (loading || !data) {
    return <div>Loading dashboard...</div>
  }

  const today = data.todayStatus
  const stats = data.stats
  const recent = data.recent || []

  return (
    <div>
      <div className="topbar">
        <h2>Employee Dashboard</h2>
      </div>
      <div className="grid grid-3">
        <div className="card">
          <div>Today</div>
          <div style={{ fontSize: 22, fontWeight: 600, marginTop: 8 }}>
            {today ? today.status.toUpperCase() : "Not Marked"}
          </div>
        </div>
        <div className="card">
          <div>This Month</div>
          <div style={{ marginTop: 8, fontSize: 14 }}>
            <div>Present: {stats.present}</div>
            <div>Absent: {stats.absent}</div>
            <div>Late: {stats.late}</div>
            <div>Half Day: {stats.halfDay}</div>
          </div>
        </div>
        <div className="card">
          <div>Total Hours This Month</div>
          <div style={{ fontSize: 22, fontWeight: 600, marginTop: 8 }}>{stats.totalHours.toFixed(1)}</div>
        </div>
      </div>
      <div className="card">
        <h3>Recent Attendance</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Status</th>
              <th>Total Hours</th>
            </tr>
          </thead>
          <tbody>
            {recent.map(r => (
              <tr key={r._id}>
                <td>{new Date(r.date).toISOString().slice(0, 10)}</td>
                <td>
                  <span className={"chip " + r.status.replace("half-day", "half-day")}>{r.status}</span>
                </td>
                <td>{r.totalHours?.toFixed(1) || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default EmployeeDashboard