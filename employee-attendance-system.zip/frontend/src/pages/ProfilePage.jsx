import React from "react"
import useAuthStore from "../store/authStore"

const ProfilePage = () => {
  const { user } = useAuthStore()
  if (!user) return null
  return (
    <div>
      <div className="topbar">
        <h2>Profile</h2>
      </div>
      <div className="card">
        <div style={{ marginBottom: 8 }}>Name: {user.name}</div>
        <div style={{ marginBottom: 8 }}>Email: {user.email}</div>
        <div style={{ marginBottom: 8 }}>Employee ID: {user.employeeId}</div>
        <div style={{ marginBottom: 8 }}>Department: {user.department}</div>
        <div style={{ marginBottom: 8 }}>Role: {user.role}</div>
      </div>
    </div>
  )
}

export default ProfilePage