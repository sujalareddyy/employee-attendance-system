import React, { useEffect, useState } from "react"
import { api } from "../api"

const AllAttendance = () => {
  const [records, setRecords] = useState([])
  const [filters, setFilters] = useState({
    employeeId: "",
    date: "",
    status: ""
  })

  const load = async () => {
    try {
      const res = await api.get("/attendance/all", { params: filters })
      setRecords(res.data.records)
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleChange = e => {
    setFilters({ ...filters, [e.target.name]: e.target.value })
  }

  const handleApply = () => {
    load()
  }

  return (
    <div>
      <div className="topbar">
        <h2>All Attendance</h2>
      </div>
      <div className="card">
        <div className="grid grid-3">
          <div className="form-group">
            <label>Employee ID</label>
            <input name="employeeId" value={filters.employeeId} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Date</label>
            <input name="date" type="date" value={filters.date} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Status</label>
            <select name="status" value={filters.status} onChange={handleChange}>
              <option value="">All</option>
              <option value="present">Present</option>
              <option value="late">Late</option>
              <option value="absent">Absent</option>
              <option value="half-day">Half Day</option>
            </select>
          </div>
        </div>
        <button className="button" style={{ marginTop: 8 }} onClick={handleApply}>
          Apply Filters
        </button>
      </div>
      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Employee</th>
              <th>Employee ID</th>
              <th>Department</th>
              <th>Status</th>
              <th>Total Hours</th>
            </tr>
          </thead>
          <tbody>
            {records.map(r => (
              <tr key={r._id}>
                <td>{new Date(r.date).toISOString().slice(0, 10)}</td>
                <td>{r.userId?.name}</td>
                <td>{r.userId?.employeeId}</td>
                <td>{r.userId?.department}</td>
                <td>
                  <span className={"chip " + r.status.replace("half-day", "half-day")}>{r.status}</span>
                </td>
                <td>{r.totalHours?.toFixed(1) || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default AllAttendance